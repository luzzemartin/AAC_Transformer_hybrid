import sys, math, random, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from aac_lm import CanonicalAACLM, ByteTokenizer
import torch, torch.nn.functional as F


def make_assoc(tok, n=800, pairs=3, gap=80, seed=0):
    rng=random.Random(seed); texts=[]
    keys=[chr(65+i) for i in range(pairs)]
    vals=[chr(97+i) for i in range(pairs)]
    filler=' xyzmnopqrstu'
    for _ in range(n):
        perm=list(range(pairs)); rng.shuffle(perm)
        s=''.join(f'K{keys[i]}V{vals[i]}' for i in perm)
        s += filler*((gap//len(filler))+1)
        for i in perm: s += f'K{keys[i]}'
        texts.append(s+'\n')
    return ''.join(texts)


def chunks(ids,L):
    return [ids[i:i+L+1] for i in range(0,len(ids)-L,L) if len(ids[i:i+L+1])==L+1]


def train_eval(gap, seed=0):
    tok=ByteTokenizer(); text=make_assoc(tok, n=900, pairs=3, gap=gap, seed=seed)
    ids=tok.encode(text); cut=int(.85*len(ids)); tr=chunks(ids[:cut],96); va=chunks(ids[cut:],96)
    m=CanonicalAACLM(d_model=32,seed=seed); opt=torch.optim.AdamW(m.parameters(),lr=5e-4)
    for step in range(250):
        b=torch.tensor(random.sample(tr,min(8,len(tr))),dtype=torch.long)
        logits=m(b[:,:-1]); y=b[:,1:]
        loss=F.cross_entropy(logits.reshape(-1,259),y.reshape(-1))
        opt.zero_grad(); loss.backward(); torch.nn.utils.clip_grad_norm_(m.parameters(),1.0); opt.step()
    m.eval(); tot=hit=0; loss_sum=0; qtot=qhit=0; qhit_nomem=0
    with torch.no_grad():
      for c in va[:100]:
        b=torch.tensor([c]); inp=b[:,:-1]; y=b[:,1:]
        lg=m(inp); lgn=m(inp,memory_scale=0.0)
        loss_sum += F.cross_entropy(lg.reshape(-1,259),y.reshape(-1),reduction='sum').item(); tot += y.numel()
        hit += (lg.argmax(-1)==y).sum().item()
        # Query positions: in raw bytes, after K + uppercase key byte,
        # next byte should be V (the learned long-range association).
        arr=c
        for t in range(0,len(arr)-2):
            if arr[t]==ord('K') and 65 <= arr[t+1] <= 90:
                # only queries occur after the long filler: identify K that is
                # not immediately followed by V; the target is V.
                if arr[t+2] == ord('V'):
                    continue
                pos=t+1
                if pos < lg.shape[1]:
                    qtot += 1
                    qhit += int(lg[0,pos].argmax().item()==ord('V'))
                    qhit_nomem += int(lgn[0,pos].argmax().item()==ord('V'))
    return {'gap':gap,'val_ppl':math.exp(loss_sum/tot),'byte_acc':hit/tot,'query_V_acc':qhit/max(1,qtot),'query_V_acc_no_memory':qhit_nomem/max(1,qtot),'query_count':qtot,'params':sum(p.numel() for p in m.parameters())}

if __name__=='__main__':
    random.seed(0); torch.manual_seed(0)
    out=[]
    for g in [80]:
        r=train_eval(g); print(r,flush=True); out.append(r)
    print(json.dumps(out,indent=2))
