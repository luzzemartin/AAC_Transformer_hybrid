# AAC v1.2 – Canonical Associative Architecture + Hybrid Canonical-Transformer

Clean package containing:

1. **Canonical AAC Language Model** (Phase-4.5 `AACDiffFinal`)
2. **Canonical-Transformer Hybrid** – 8 hybrid blocks (Canonical AAC → Transformer)

---

## Architecture Summary

### Canonical AAC Core (unchanged)

At each token:

```
S_t = tanh(W_hh S_{t-1} + W_xh e_t + b_h)
T_t = λ_T · T_{t-1} + g_keep,t · v_t          (λ_T = 0.9)
p_t = σ( Value(S_t, T_t, e_t) )
P_t = λ_P · P_{t-1} + p_t · (k_t ⊗ v_t)       (λ_P = 0.9999 fixed)
r_t = q_tᵀ P_t
h_t = tanh(W_comb [S_t ; r_t] + b_comb)
```

Key canonical choices retained:
- Fixed high-persistence decay on the associative matrix
- Direct outer-product write (no matrix-level reinforce/evict)
- Temporary trace `T` is only evidence for the utility/value estimator
- Causal / non-circular token order

### Canonical-Transformer Hybrid (new)

Stack of **8 identical hybrid blocks**. Inside each block:

1. Full-sequence Canonical AAC pass → produces associative-memory-augmented hidden states
2. Pre-norm causal Transformer block (Multi-Head Self-Attention + GELU FFN)

Residual connections around the AAC and around the Transformer sub-block.
Final LayerNorm + tied embedding head.

---

## Package Layout

```
AAC_v1.2_clean/
├── README.md
├── aac_lm/
│   ├── __init__.py
│   ├── model.py                 # Original CanonicalAACLM + ByteTokenizer + training helpers
│   ├── canonical_transformer.py # Hybrid model (8-block Canonical → Transformer)
│   └── README.md                # Original notes
├── checkpoints/
│   ├── aac_canonical_lm_synth.pt          # Original 2-epoch synthetic checkpoint (d_model=48)
│   └── aac_canonical_lm_continued.pt      # Continued training checkpoint
└── scripts/
    ├── continue_train.py                  # Continue pure AAC training
    ├── train_canonical_transformer.py     # Train the 8-block hybrid
    ├── test_aac_lm_capabilities.py
    └── test_word_assoc.py
```

---

## Quick Start

```bash
# Pure Canonical AAC (original)
python -c "
from aac_lm import CanonicalAACLM, ByteTokenizer
model = CanonicalAACLM(d_model=48)
print(sum(p.numel() for p in model.parameters()))
"

# 8-block Canonical-Transformer hybrid
python -c "
from aac_lm import CanonicalTransformerLM
model = CanonicalTransformerLM(d_model=48, n_layers=8, n_heads=4)
print(sum(p.numel() for p in model.parameters()))
"

# Train the hybrid (example)
cd scripts
python train_canonical_transformer.py
```

---

## Reported Results (synthetic structured corpus)

### Pure Canonical AAC (continued training)
- After loading original checkpoint: ppl ≈ 16.85, acc ≈ 31%
- After +4 epochs: **ppl ≈ 2.16**, **acc ≈ 84%**

### 8-block Canonical-Transformer Hybrid
- Random init: ppl ≈ 262, acc ≈ 0.1%
- After 1 epoch (d_model=48, ~431k params): **ppl ≈ 1.17**, **acc ≈ 96%**

The hybrid reaches near-perfect fit on the synthetic associative corpus significantly faster and with lower final perplexity than the single-layer AAC, while preserving the canonical associative memory mechanism inside every block.

---

## Notes & Caveats

- The original AAC was developed primarily around associative-recall / MQAR-style tasks.
- The hybrid adds depth and non-local mixing via the Transformer sub-layers while keeping the Phase-4.5 equations intact.
- All results above are on a small synthetic structured corpus; they are capability / smoke tests, not claims of large-scale natural-language performance.
- Training the hybrid is sequential-heavy (AAC outer-products at every timestep × 8 layers). Use modest `d_model`, `seq_len` and `batch_size` on CPU.

---

## License / Origin

Derived from the supplied AAC v1.2 canonical Phase-4.5 implementation.
